# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'e06ef137d645543994808ce71db095ebeb38ee8a66fd2c41817ed4ccaab7b991b7505cfa79f4cecaedf56a2cd6561ffeddb2490746f88704dcc1dd7328dc36f1'