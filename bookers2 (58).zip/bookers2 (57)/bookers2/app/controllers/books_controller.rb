class BooksController < ApplicationController
  
   before_action :correct_user, only: [:edit]
  
  def index
    @books = Book.all
    @user = User.find(current_user.id)
    @book = Book.new
  end

  def create
    @books = Book.all
    @user = User.find(current_user.id)
    @book = Book.new(book_params)
    @book.user_id = current_user.id
     if @book.save
       flash[:notice] = "You have created book successfully."
       redirect_to book_path(@book)
     else
       render :index
     end
  end

  def show
    @user = User.find(current_user.id)
    @book = Book.new
    @books = Book.find(params[:id])
  end

  def edit
    @books = Book.find(params[:id])
    unless @books.user == current_user
      redirect_to books_path(current_book.id)
    end
  end

  def update
    @books = Book.find(params[:id])
   if @books.update(book_params)
     flash[:notice] = "You have updated book successfully."
     redirect_to book_path(@books.id)
   else
     render :edit
   end
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
    redirect_to books_path
  end



  def book_params
    params.require(:book).permit(:title, :body, :user_id)
  end
  
   def correct_user
    @books = Book.find(params[:id])
    @user = @books.user
    redirect_to(books_path) unless @user == current_user
   end
end
